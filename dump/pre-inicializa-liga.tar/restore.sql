--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "7c919630_d776_465b_a173_870531c94c69";
--
-- Name: 7c919630_d776_465b_a173_870531c94c69; Type: DATABASE; Schema: -; Owner: voleibol
--

CREATE DATABASE "7c919630_d776_465b_a173_870531c94c69" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE "7c919630_d776_465b_a173_870531c94c69" OWNER TO voleibol;

\connect "7c919630_d776_465b_a173_870531c94c69"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: arbitros_partida_tipo_enum; Type: TYPE; Schema: public; Owner: voleibol
--

CREATE TYPE public.arbitros_partida_tipo_enum AS ENUM (
    'principal'
);


ALTER TYPE public.arbitros_partida_tipo_enum OWNER TO voleibol;

--
-- Name: atletas_escalados_posicao_enum; Type: TYPE; Schema: public; Owner: voleibol
--

CREATE TYPE public.atletas_escalados_posicao_enum AS ENUM (
    'ponta',
    'oposto',
    'central',
    'libero',
    'levantador'
);


ALTER TYPE public.atletas_escalados_posicao_enum OWNER TO voleibol;

--
-- Name: atletas_partida_posicao_enum; Type: TYPE; Schema: public; Owner: voleibol
--

CREATE TYPE public.atletas_partida_posicao_enum AS ENUM (
    'ponta',
    'oposto',
    'central',
    'libero',
    'levantador'
);


ALTER TYPE public.atletas_partida_posicao_enum OWNER TO voleibol;

--
-- Name: auxiliares_tipo_auxiliar_enum; Type: TYPE; Schema: public; Owner: voleibol
--

CREATE TYPE public.auxiliares_tipo_auxiliar_enum AS ENUM (
    'assistente_medico',
    'auxiliar_tecnico',
    'preparador_fisico',
    'fisioterapeuta',
    'medico',
    'massagista'
);


ALTER TYPE public.auxiliares_tipo_auxiliar_enum OWNER TO voleibol;

--
-- Name: ligas_status_enum; Type: TYPE; Schema: public; Owner: voleibol
--

CREATE TYPE public.ligas_status_enum AS ENUM (
    'criada',
    'classificatória',
    'quartas',
    'semis',
    'final',
    'premiacao',
    'concluida'
);


ALTER TYPE public.ligas_status_enum OWNER TO voleibol;

--
-- Name: partida_status_enum; Type: TYPE; Schema: public; Owner: voleibol
--

CREATE TYPE public.partida_status_enum AS ENUM (
    'agendada',
    'em_andamento',
    'concluida'
);


ALTER TYPE public.partida_status_enum OWNER TO voleibol;

--
-- Name: partidas_status_enum; Type: TYPE; Schema: public; Owner: voleibol
--

CREATE TYPE public.partidas_status_enum AS ENUM (
    'agendada',
    'participantes_cadastrados',
    'wo',
    'concluida'
);


ALTER TYPE public.partidas_status_enum OWNER TO voleibol;

--
-- Name: partidas_tipo_da_rodada_enum; Type: TYPE; Schema: public; Owner: voleibol
--

CREATE TYPE public.partidas_tipo_da_rodada_enum AS ENUM (
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
    '11',
    '12',
    '13',
    '14',
    '15',
    '16',
    '17',
    '18',
    '19',
    '20',
    '21',
    '22',
    '23',
    '24',
    '25',
    '26',
    '27',
    '28',
    '29',
    '30',
    'quartas',
    'semis',
    'final'
);


ALTER TYPE public.partidas_tipo_da_rodada_enum OWNER TO voleibol;

--
-- Name: pessoas_genero_enum; Type: TYPE; Schema: public; Owner: voleibol
--

CREATE TYPE public.pessoas_genero_enum AS ENUM (
    'feminino',
    'masculino'
);


ALTER TYPE public.pessoas_genero_enum OWNER TO voleibol;

--
-- Name: pessoas_tipo_enum; Type: TYPE; Schema: public; Owner: voleibol
--

CREATE TYPE public.pessoas_tipo_enum AS ENUM (
    'arbitro',
    'tecnico',
    'atleta',
    'auxiliar',
    'delegado'
);


ALTER TYPE public.pessoas_tipo_enum OWNER TO voleibol;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: arbitros; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.arbitros (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_pessoa uuid NOT NULL,
    id_liga uuid NOT NULL
);


ALTER TABLE public.arbitros OWNER TO voleibol;

--
-- Name: arbitros_partida; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.arbitros_partida (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_arbitro uuid NOT NULL,
    id_partida uuid NOT NULL,
    tipo public.arbitros_partida_tipo_enum NOT NULL
);


ALTER TABLE public.arbitros_partida OWNER TO voleibol;

--
-- Name: atletas; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.atletas (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_pessoa uuid NOT NULL,
    id_equipe uuid NOT NULL,
    numero smallint NOT NULL
);


ALTER TABLE public.atletas OWNER TO voleibol;

--
-- Name: atletas_escalados; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.atletas_escalados (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_equipe_partida uuid NOT NULL,
    id_atleta uuid NOT NULL,
    posicao public.atletas_escalados_posicao_enum NOT NULL
);


ALTER TABLE public.atletas_escalados OWNER TO voleibol;

--
-- Name: atletas_partida; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.atletas_partida (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_partida uuid NOT NULL,
    id_atleta uuid NOT NULL,
    posicao public.atletas_partida_posicao_enum NOT NULL
);


ALTER TABLE public.atletas_partida OWNER TO voleibol;

--
-- Name: auxiliares; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.auxiliares (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_pessoa uuid NOT NULL,
    id_equipe uuid NOT NULL,
    tipo_auxiliar public.auxiliares_tipo_auxiliar_enum NOT NULL,
    documento_cref character varying(50) NOT NULL
);


ALTER TABLE public.auxiliares OWNER TO voleibol;

--
-- Name: votos_da_galera; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.votos_da_galera (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_atleta uuid NOT NULL,
    telefone character varying NOT NULL,
    id_verificacao character varying NOT NULL,
    verificado_em timestamp without time zone,
    verificacao_expira_em timestamp without time zone NOT NULL
);


ALTER TABLE public.votos_da_galera OWNER TO voleibol;

--
-- Name: craques_da_galera_view; Type: MATERIALIZED VIEW; Schema: public; Owner: voleibol
--

CREATE MATERIALIZED VIEW public.craques_da_galera_view AS
 SELECT a.id AS id_atleta,
    count(vg.id) AS quantidade_votos
   FROM (public.votos_da_galera vg
     JOIN public.atletas a ON ((a.id = vg.id_atleta)))
  WHERE (vg.verificado_em IS NOT NULL)
  GROUP BY a.id
  WITH NO DATA;


ALTER TABLE public.craques_da_galera_view OWNER TO voleibol;

--
-- Name: delegados; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.delegados (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_pessoa uuid NOT NULL,
    id_liga uuid NOT NULL
);


ALTER TABLE public.delegados OWNER TO voleibol;

--
-- Name: equipes; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.equipes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    nome character varying(255) NOT NULL,
    url_brasao character varying,
    apta boolean DEFAULT false NOT NULL,
    descricao_aptidao jsonb,
    id_liga uuid NOT NULL,
    id_ginasio uuid NOT NULL,
    estado character varying(20) NOT NULL,
    cidade character varying NOT NULL
);


ALTER TABLE public.equipes OWNER TO voleibol;

--
-- Name: equipes_partidas; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.equipes_partidas (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_equipe uuid NOT NULL,
    id_partida uuid,
    pontuacao integer DEFAULT 0 NOT NULL,
    sets_ganhos integer DEFAULT 0 NOT NULL,
    pontos_nos_sets jsonb DEFAULT '[]'::jsonb NOT NULL,
    sets_disputados integer GENERATED ALWAYS AS (COALESCE(jsonb_array_length(pontos_nos_sets), 0)) STORED NOT NULL,
    ganhou smallint GENERATED ALWAYS AS (((pontuacao > 1))::integer) STORED NOT NULL,
    resultado_cadastrado_em timestamp without time zone
);


ALTER TABLE public.equipes_partidas OWNER TO voleibol;

--
-- Name: fundamentos_atletas; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.fundamentos_atletas (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_atleta_escalado uuid NOT NULL,
    bloqueios integer DEFAULT 0 NOT NULL,
    recepcoes integer DEFAULT 0 NOT NULL,
    aces integer DEFAULT 0 NOT NULL,
    saques integer DEFAULT 0 NOT NULL,
    ataques integer DEFAULT 0 NOT NULL,
    pontos integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.fundamentos_atletas OWNER TO voleibol;

--
-- Name: ginasios; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.ginasios (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    nome character varying NOT NULL,
    cidade character varying NOT NULL,
    estado character varying NOT NULL,
    capacidade integer DEFAULT 1000 NOT NULL
);


ALTER TABLE public.ginasios OWNER TO voleibol;

--
-- Name: ligas; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.ligas (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    genero character varying NOT NULL,
    nome character varying,
    serie character varying(40) DEFAULT 'A'::character varying,
    configuracao_inicializacao_liga jsonb,
    status public.ligas_status_enum DEFAULT 'criada'::public.ligas_status_enum NOT NULL,
    data_comeco timestamp without time zone
);


ALTER TABLE public.ligas OWNER TO voleibol;

--
-- Name: melhores_centrais_view; Type: MATERIALIZED VIEW; Schema: public; Owner: voleibol
--

CREATE MATERIALIZED VIEW public.melhores_centrais_view AS
 WITH ac AS (
         SELECT a.id,
            count(f.id) AS qtd,
            sum(f.bloqueios) AS total
           FROM ((public.fundamentos_atletas f
             JOIN public.atletas_escalados ae ON (((ae.id = f.id_atleta_escalado) AND (ae.posicao = 'central'::public.atletas_escalados_posicao_enum))))
             JOIN public.atletas a ON ((a.id = ae.id_atleta)))
          GROUP BY a.id
        )
 SELECT ac.id AS id_atleta,
    ac.qtd AS quantidade_partidas,
    COALESCE((ac.total / NULLIF(ac.qtd, 0)), (0)::bigint) AS bloqueios_por_partida
   FROM ac
  WITH NO DATA;


ALTER TABLE public.melhores_centrais_view OWNER TO voleibol;

--
-- Name: melhores_liberos_view; Type: MATERIALIZED VIEW; Schema: public; Owner: voleibol
--

CREATE MATERIALIZED VIEW public.melhores_liberos_view AS
 WITH ac AS (
         SELECT a.id,
            count(f.id) AS qtd,
            sum(f.recepcoes) AS total
           FROM ((public.fundamentos_atletas f
             JOIN public.atletas_escalados ae ON (((ae.id = f.id_atleta_escalado) AND (ae.posicao = 'libero'::public.atletas_escalados_posicao_enum))))
             JOIN public.atletas a ON ((a.id = ae.id_atleta)))
          GROUP BY a.id
        )
 SELECT ac.id AS id_atleta,
    ac.qtd AS quantidade_partidas,
    COALESCE((ac.total / NULLIF(ac.qtd, 0)), (0)::bigint) AS recepcoes_por_partida
   FROM ac
  WITH NO DATA;


ALTER TABLE public.melhores_liberos_view OWNER TO voleibol;

--
-- Name: melhores_pontas_view; Type: MATERIALIZED VIEW; Schema: public; Owner: voleibol
--

CREATE MATERIALIZED VIEW public.melhores_pontas_view AS
 WITH ac AS (
         SELECT a.id,
            count(f.id) AS qtd,
            sum(f.aces) AS total_aces,
            sum(f.saques) AS total_saques
           FROM ((public.fundamentos_atletas f
             JOIN public.atletas_escalados ae ON (((ae.id = f.id_atleta_escalado) AND (ae.posicao = 'ponta'::public.atletas_escalados_posicao_enum))))
             JOIN public.atletas a ON ((a.id = ae.id_atleta)))
          GROUP BY a.id
        )
 SELECT ac.id AS id_atleta,
    ac.qtd AS quantidade_partidas,
    COALESCE((ac.total_aces / NULLIF(ac.qtd, 0)), (0)::bigint) AS aces_por_partida,
    COALESCE((ac.total_aces / NULLIF(ac.total_saques, 0)), (0)::bigint) AS saques_efetivos
   FROM ac
  WITH NO DATA;


ALTER TABLE public.melhores_pontas_view OWNER TO voleibol;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO voleibol;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: voleibol
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO voleibol;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: voleibol
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: partidas; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.partidas (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_delegado uuid,
    id_ginasio uuid NOT NULL,
    id_mandante uuid NOT NULL,
    id_visitante uuid NOT NULL,
    status public.partidas_status_enum DEFAULT 'agendada'::public.partidas_status_enum NOT NULL,
    data_comeco timestamp without time zone NOT NULL,
    data_finalizacao timestamp without time zone,
    tipo_da_rodada public.partidas_tipo_da_rodada_enum NOT NULL,
    id_ganhadora uuid
);


ALTER TABLE public.partidas OWNER TO voleibol;

--
-- Name: pessoas; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.pessoas (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    nome character varying(255) NOT NULL,
    documento character varying(50) NOT NULL,
    genero public.pessoas_genero_enum NOT NULL,
    data_nascimento timestamp without time zone NOT NULL,
    documento_cbv character varying(50) NOT NULL,
    tipo public.pessoas_tipo_enum NOT NULL
);


ALTER TABLE public.pessoas OWNER TO voleibol;

--
-- Name: pontuacoes_view; Type: MATERIALIZED VIEW; Schema: public; Owner: voleibol
--

CREATE MATERIALIZED VIEW public.pontuacoes_view AS
 WITH total_pontos_ep AS (
         SELECT ep_1.id,
            COALESCE(sum(((jsonb_array_elements.value ->> 'quantidade'::text))::integer), (0)::bigint) AS total_pontos
           FROM ((public.equipes_partidas ep_1
             JOIN public.partidas p ON (((p.id = ep_1.id_partida) AND (p.tipo_da_rodada = ANY (ARRAY['1'::public.partidas_tipo_da_rodada_enum, '2'::public.partidas_tipo_da_rodada_enum, '3'::public.partidas_tipo_da_rodada_enum, '4'::public.partidas_tipo_da_rodada_enum, '5'::public.partidas_tipo_da_rodada_enum, '6'::public.partidas_tipo_da_rodada_enum, '7'::public.partidas_tipo_da_rodada_enum, '8'::public.partidas_tipo_da_rodada_enum, '9'::public.partidas_tipo_da_rodada_enum, '10'::public.partidas_tipo_da_rodada_enum, '11'::public.partidas_tipo_da_rodada_enum, '12'::public.partidas_tipo_da_rodada_enum, '13'::public.partidas_tipo_da_rodada_enum, '14'::public.partidas_tipo_da_rodada_enum, '15'::public.partidas_tipo_da_rodada_enum, '16'::public.partidas_tipo_da_rodada_enum, '17'::public.partidas_tipo_da_rodada_enum, '18'::public.partidas_tipo_da_rodada_enum, '19'::public.partidas_tipo_da_rodada_enum, '20'::public.partidas_tipo_da_rodada_enum, '21'::public.partidas_tipo_da_rodada_enum, '22'::public.partidas_tipo_da_rodada_enum])))))
             CROSS JOIN LATERAL jsonb_array_elements(ep_1.pontos_nos_sets) jsonb_array_elements(value))
          GROUP BY ep_1.id
        ), partidas_disputadas AS (
         SELECT ep_1.id_equipe AS id,
            count(p.id) AS qtd,
            sum(ep_1.ganhou) AS ganhou
           FROM (public.equipes_partidas ep_1
             JOIN public.partidas p ON (((p.id = ep_1.id_partida) AND (p.status = ANY (ARRAY['wo'::public.partidas_status_enum, 'concluida'::public.partidas_status_enum])))))
          GROUP BY ep_1.id_equipe
        )
 SELECT e.id AS id_equipe,
    sum(ep.pontuacao) AS pontuacao,
    sum(ep.sets_ganhos) AS sets_ganhos,
    sum(ep.sets_disputados) AS sets_disputados,
    COALESCE(pd.qtd, (0)::bigint) AS partidas_disputadas,
    COALESCE(pd.ganhou, (0)::bigint) AS partidas_ganhas,
    (sum(ep.sets_disputados) - sum(ep.sets_ganhos)) AS sets_perdidos,
    (COALESCE(pd.qtd, (0)::bigint) - COALESCE(pd.ganhou, (0)::bigint)) AS partidas_perdidas,
    COALESCE(((sum(total_pontos_ep.total_pontos))::double precision / (NULLIF(sum(ep.sets_disputados), 0))::double precision), (0)::double precision) AS pontos_average,
    COALESCE(((sum(ep.sets_ganhos))::double precision / (NULLIF(sum(ep.sets_disputados), 0))::double precision), (0)::double precision) AS sets_average
   FROM (((public.equipes e
     JOIN public.equipes_partidas ep ON ((ep.id_equipe = e.id)))
     LEFT JOIN total_pontos_ep ON ((total_pontos_ep.id = ep.id)))
     LEFT JOIN partidas_disputadas pd ON ((pd.id = e.id)))
  GROUP BY e.id, pd.qtd, pd.ganhou
  WITH NO DATA;


ALTER TABLE public.pontuacoes_view OWNER TO voleibol;

--
-- Name: tecnicos; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.tecnicos (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    id_pessoa uuid NOT NULL,
    id_equipe uuid NOT NULL,
    documento_cref character varying(50) NOT NULL
);


ALTER TABLE public.tecnicos OWNER TO voleibol;

--
-- Name: typeorm_metadata; Type: TABLE; Schema: public; Owner: voleibol
--

CREATE TABLE public.typeorm_metadata (
    type character varying NOT NULL,
    database character varying,
    schema character varying,
    "table" character varying,
    name character varying,
    value text
);


ALTER TABLE public.typeorm_metadata OWNER TO voleibol;

--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: arbitros; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.arbitros (id, data_atualizacao, data_criacao, id_pessoa, id_liga) FROM stdin;
\.
COPY public.arbitros (id, data_atualizacao, data_criacao, id_pessoa, id_liga) FROM '$$PATH$$/3665.dat';

--
-- Data for Name: arbitros_partida; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.arbitros_partida (id, data_atualizacao, data_criacao, id_arbitro, id_partida, tipo) FROM stdin;
\.
COPY public.arbitros_partida (id, data_atualizacao, data_criacao, id_arbitro, id_partida, tipo) FROM '$$PATH$$/3667.dat';

--
-- Data for Name: atletas; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.atletas (id, data_atualizacao, data_criacao, id_pessoa, id_equipe, numero) FROM stdin;
\.
COPY public.atletas (id, data_atualizacao, data_criacao, id_pessoa, id_equipe, numero) FROM '$$PATH$$/3659.dat';

--
-- Data for Name: atletas_escalados; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.atletas_escalados (id, data_atualizacao, data_criacao, id_equipe_partida, id_atleta, posicao) FROM stdin;
\.
COPY public.atletas_escalados (id, data_atualizacao, data_criacao, id_equipe_partida, id_atleta, posicao) FROM '$$PATH$$/3671.dat';

--
-- Data for Name: atletas_partida; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.atletas_partida (id, data_atualizacao, data_criacao, id_partida, id_atleta, posicao) FROM stdin;
\.
COPY public.atletas_partida (id, data_atualizacao, data_criacao, id_partida, id_atleta, posicao) FROM '$$PATH$$/3669.dat';

--
-- Data for Name: auxiliares; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.auxiliares (id, data_atualizacao, data_criacao, id_pessoa, id_equipe, tipo_auxiliar, documento_cref) FROM stdin;
\.
COPY public.auxiliares (id, data_atualizacao, data_criacao, id_pessoa, id_equipe, tipo_auxiliar, documento_cref) FROM '$$PATH$$/3666.dat';

--
-- Data for Name: delegados; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.delegados (id, data_atualizacao, data_criacao, id_pessoa, id_liga) FROM stdin;
\.
COPY public.delegados (id, data_atualizacao, data_criacao, id_pessoa, id_liga) FROM '$$PATH$$/3664.dat';

--
-- Data for Name: equipes; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.equipes (id, data_atualizacao, data_criacao, nome, url_brasao, apta, descricao_aptidao, id_liga, id_ginasio, estado, cidade) FROM stdin;
\.
COPY public.equipes (id, data_atualizacao, data_criacao, nome, url_brasao, apta, descricao_aptidao, id_liga, id_ginasio, estado, cidade) FROM '$$PATH$$/3661.dat';

--
-- Data for Name: equipes_partidas; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.equipes_partidas (id, data_atualizacao, data_criacao, id_equipe, id_partida, pontuacao, sets_ganhos, pontos_nos_sets, resultado_cadastrado_em) FROM stdin;
\.
COPY public.equipes_partidas (id, data_atualizacao, data_criacao, id_equipe, id_partida, pontuacao, sets_ganhos, pontos_nos_sets, resultado_cadastrado_em) FROM '$$PATH$$/3672.dat';

--
-- Data for Name: fundamentos_atletas; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.fundamentos_atletas (id, data_atualizacao, data_criacao, id_atleta_escalado, bloqueios, recepcoes, aces, saques, ataques, pontos) FROM stdin;
\.
COPY public.fundamentos_atletas (id, data_atualizacao, data_criacao, id_atleta_escalado, bloqueios, recepcoes, aces, saques, ataques, pontos) FROM '$$PATH$$/3670.dat';

--
-- Data for Name: ginasios; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.ginasios (id, data_atualizacao, data_criacao, nome, cidade, estado, capacidade) FROM stdin;
\.
COPY public.ginasios (id, data_atualizacao, data_criacao, nome, cidade, estado, capacidade) FROM '$$PATH$$/3663.dat';

--
-- Data for Name: ligas; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.ligas (id, data_atualizacao, data_criacao, genero, nome, serie, configuracao_inicializacao_liga, status, data_comeco) FROM stdin;
\.
COPY public.ligas (id, data_atualizacao, data_criacao, genero, nome, serie, configuracao_inicializacao_liga, status, data_comeco) FROM '$$PATH$$/3662.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
\.
COPY public.migrations (id, "timestamp", name) FROM '$$PATH$$/3656.dat';

--
-- Data for Name: partidas; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.partidas (id, data_atualizacao, data_criacao, id_delegado, id_ginasio, id_mandante, id_visitante, status, data_comeco, data_finalizacao, tipo_da_rodada, id_ganhadora) FROM stdin;
\.
COPY public.partidas (id, data_atualizacao, data_criacao, id_delegado, id_ginasio, id_mandante, id_visitante, status, data_comeco, data_finalizacao, tipo_da_rodada, id_ganhadora) FROM '$$PATH$$/3668.dat';

--
-- Data for Name: pessoas; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.pessoas (id, data_atualizacao, data_criacao, nome, documento, genero, data_nascimento, documento_cbv, tipo) FROM stdin;
\.
COPY public.pessoas (id, data_atualizacao, data_criacao, nome, documento, genero, data_nascimento, documento_cbv, tipo) FROM '$$PATH$$/3658.dat';

--
-- Data for Name: tecnicos; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.tecnicos (id, data_atualizacao, data_criacao, id_pessoa, id_equipe, documento_cref) FROM stdin;
\.
COPY public.tecnicos (id, data_atualizacao, data_criacao, id_pessoa, id_equipe, documento_cref) FROM '$$PATH$$/3660.dat';

--
-- Data for Name: typeorm_metadata; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.typeorm_metadata (type, database, schema, "table", name, value) FROM stdin;
\.
COPY public.typeorm_metadata (type, database, schema, "table", name, value) FROM '$$PATH$$/3657.dat';

--
-- Data for Name: votos_da_galera; Type: TABLE DATA; Schema: public; Owner: voleibol
--

COPY public.votos_da_galera (id, data_atualizacao, data_criacao, id_atleta, telefone, id_verificacao, verificado_em, verificacao_expira_em) FROM stdin;
\.
COPY public.votos_da_galera (id, data_atualizacao, data_criacao, id_atleta, telefone, id_verificacao, verificado_em, verificacao_expira_em) FROM '$$PATH$$/3676.dat';

--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: voleibol
--

SELECT pg_catalog.setval('public.migrations_id_seq', 43, true);


--
-- Name: delegados PK_17a4a565077e2739d85da5a5afd; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.delegados
    ADD CONSTRAINT "PK_17a4a565077e2739d85da5a5afd" PRIMARY KEY (id);


--
-- Name: atletas PK_209e4ca399219bce544fac44dec; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas
    ADD CONSTRAINT "PK_209e4ca399219bce544fac44dec" PRIMARY KEY (id);


--
-- Name: equipes_partidas PK_24349dada80e22369201346b0e9; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.equipes_partidas
    ADD CONSTRAINT "PK_24349dada80e22369201346b0e9" PRIMARY KEY (id);


--
-- Name: atletas_escalados PK_27087bacfdaee173e8fda1bcdcc; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas_escalados
    ADD CONSTRAINT "PK_27087bacfdaee173e8fda1bcdcc" PRIMARY KEY (id);


--
-- Name: arbitros_partida PK_2b4e130b3202e3802f7de26c329; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.arbitros_partida
    ADD CONSTRAINT "PK_2b4e130b3202e3802f7de26c329" PRIMARY KEY (id);


--
-- Name: auxiliares PK_2ecfd0cd470ecf689bc62abd335; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.auxiliares
    ADD CONSTRAINT "PK_2ecfd0cd470ecf689bc62abd335" PRIMARY KEY (id);


--
-- Name: ligas PK_461f18cdc237818a4d9f2cebc9f; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.ligas
    ADD CONSTRAINT "PK_461f18cdc237818a4d9f2cebc9f" PRIMARY KEY (id);


--
-- Name: tecnicos PK_57a82263172b130f3dafce11faa; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.tecnicos
    ADD CONSTRAINT "PK_57a82263172b130f3dafce11faa" PRIMARY KEY (id);


--
-- Name: arbitros PK_628ab77296ad7f03e340ba72406; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.arbitros
    ADD CONSTRAINT "PK_628ab77296ad7f03e340ba72406" PRIMARY KEY (id);


--
-- Name: fundamentos_atletas PK_67211888fdbc91d8bc3e3496d98; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.fundamentos_atletas
    ADD CONSTRAINT "PK_67211888fdbc91d8bc3e3496d98" PRIMARY KEY (id);


--
-- Name: partidas PK_6e9cc7455a900d190278156517c; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.partidas
    ADD CONSTRAINT "PK_6e9cc7455a900d190278156517c" PRIMARY KEY (id);


--
-- Name: atletas_partida PK_7cf400fce1a35afc733208a2269; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas_partida
    ADD CONSTRAINT "PK_7cf400fce1a35afc733208a2269" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: ginasios PK_930dd1915a2b4d5865733a462df; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.ginasios
    ADD CONSTRAINT "PK_930dd1915a2b4d5865733a462df" PRIMARY KEY (id);


--
-- Name: equipes PK_9f0bfc492ee9542b0c0f42eb21d; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.equipes
    ADD CONSTRAINT "PK_9f0bfc492ee9542b0c0f42eb21d" PRIMARY KEY (id);


--
-- Name: votos_da_galera PK_a82aee84e7ffb11cd8aadd3acf7; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.votos_da_galera
    ADD CONSTRAINT "PK_a82aee84e7ffb11cd8aadd3acf7" PRIMARY KEY (id);


--
-- Name: pessoas PK_fa8104cfc91dc207880a73a1acd; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.pessoas
    ADD CONSTRAINT "PK_fa8104cfc91dc207880a73a1acd" PRIMARY KEY (id);


--
-- Name: atletas_escalados UQ_0ebb4fe31807a2fba26e6cfbe52; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas_escalados
    ADD CONSTRAINT "UQ_0ebb4fe31807a2fba26e6cfbe52" UNIQUE (id_atleta, id_equipe_partida);


--
-- Name: votos_da_galera UQ_2aff92fd5886c18acd681d629e3; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.votos_da_galera
    ADD CONSTRAINT "UQ_2aff92fd5886c18acd681d629e3" UNIQUE (id_verificacao);


--
-- Name: votos_da_galera UQ_52c258f86b81bb4905343bc8498; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.votos_da_galera
    ADD CONSTRAINT "UQ_52c258f86b81bb4905343bc8498" UNIQUE (id_atleta, telefone);


--
-- Name: tecnicos UQ_5630f0084bc92ed174b3d85f2ac; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.tecnicos
    ADD CONSTRAINT "UQ_5630f0084bc92ed174b3d85f2ac" UNIQUE (documento_cref);


--
-- Name: tecnicos UQ_606c789ebbaf0670a39edf937c3; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.tecnicos
    ADD CONSTRAINT "UQ_606c789ebbaf0670a39edf937c3" UNIQUE (id_pessoa);


--
-- Name: auxiliares UQ_63186f3f51e662a98fb04c176b7; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.auxiliares
    ADD CONSTRAINT "UQ_63186f3f51e662a98fb04c176b7" UNIQUE (id_pessoa);


--
-- Name: arbitros UQ_7175f8ecb699effccd191c530d3; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.arbitros
    ADD CONSTRAINT "UQ_7175f8ecb699effccd191c530d3" UNIQUE (id_pessoa);


--
-- Name: tecnicos UQ_726c77443629b22dc96a8ef714d; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.tecnicos
    ADD CONSTRAINT "UQ_726c77443629b22dc96a8ef714d" UNIQUE (id_equipe);


--
-- Name: atletas UQ_8673430de4ae5ab7edf8dba98c1; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas
    ADD CONSTRAINT "UQ_8673430de4ae5ab7edf8dba98c1" UNIQUE (id_pessoa);


--
-- Name: delegados UQ_a2b5b0b570956c36475eeb066c3; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.delegados
    ADD CONSTRAINT "UQ_a2b5b0b570956c36475eeb066c3" UNIQUE (id_pessoa);


--
-- Name: arbitros_partida UQ_ae4b3991d0adda08c553a527112; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.arbitros_partida
    ADD CONSTRAINT "UQ_ae4b3991d0adda08c553a527112" UNIQUE (id_arbitro, id_partida);


--
-- Name: atletas UQ_atletas_numero_por_equipe; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas
    ADD CONSTRAINT "UQ_atletas_numero_por_equipe" UNIQUE (numero, id_equipe);


--
-- Name: equipes UQ_b5b45eae06b288f11e5b3fcc38e; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.equipes
    ADD CONSTRAINT "UQ_b5b45eae06b288f11e5b3fcc38e" UNIQUE (id_ginasio);


--
-- Name: equipes UQ_c107f0e64f7eaa9e02e37ba147d; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.equipes
    ADD CONSTRAINT "UQ_c107f0e64f7eaa9e02e37ba147d" UNIQUE (nome);


--
-- Name: pessoas UQ_c1ab3438a61435fd355c673303f; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.pessoas
    ADD CONSTRAINT "UQ_c1ab3438a61435fd355c673303f" UNIQUE (documento_cbv);


--
-- Name: auxiliares UQ_e936074a7758778e997d1214b82; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.auxiliares
    ADD CONSTRAINT "UQ_e936074a7758778e997d1214b82" UNIQUE (documento_cref);


--
-- Name: atletas_partida UQ_f49976721f8e1ee1dca4fe786eb; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas_partida
    ADD CONSTRAINT "UQ_f49976721f8e1ee1dca4fe786eb" UNIQUE (id_atleta, id_partida);


--
-- Name: ginasios UQ_ginasios_nome_cidade_estado; Type: CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.ginasios
    ADD CONSTRAINT "UQ_ginasios_nome_cidade_estado" UNIQUE (nome, cidade, estado);


--
-- Name: IDX_0297b00b2149a7d35118c14674; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_0297b00b2149a7d35118c14674" ON public.auxiliares USING btree (tipo_auxiliar);


--
-- Name: IDX_06c48d7d3c0caecaeba906369a; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_06c48d7d3c0caecaeba906369a" ON public.tecnicos USING btree (data_criacao);


--
-- Name: IDX_185c120f3624970475d8f1df84; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_185c120f3624970475d8f1df84" ON public.auxiliares USING btree (id_equipe);


--
-- Name: IDX_2551905023f3f38587bafb7395; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_2551905023f3f38587bafb7395" ON public.pessoas USING btree (data_criacao);


--
-- Name: IDX_2d8319b8833c5b7e11f7479656; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_2d8319b8833c5b7e11f7479656" ON public.arbitros_partida USING btree (data_criacao);


--
-- Name: IDX_2dcc30b378f8e69aedb263a046; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_2dcc30b378f8e69aedb263a046" ON public.partidas USING btree (id_ganhadora);


--
-- Name: IDX_2ddf9d216ffb580e40f3e920f0; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_2ddf9d216ffb580e40f3e920f0" ON public.ligas USING btree (data_criacao);


--
-- Name: IDX_3120d2ed6a2db074dc8673ba40; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_3120d2ed6a2db074dc8673ba40" ON public.ginasios USING btree (estado);


--
-- Name: IDX_31f3de618c0b4fd37763676ee1; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_31f3de618c0b4fd37763676ee1" ON public.equipes_partidas USING btree (data_criacao);


--
-- Name: IDX_442b67bb04c95a2e04ebbbd83b; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_442b67bb04c95a2e04ebbbd83b" ON public.atletas USING btree (id_equipe);


--
-- Name: IDX_449fe4c78fb88327cd9e94c544; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_449fe4c78fb88327cd9e94c544" ON public.fundamentos_atletas USING btree (id_atleta_escalado);


--
-- Name: IDX_4575175bdc00568e84f60058b4; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_4575175bdc00568e84f60058b4" ON public.votos_da_galera USING btree (data_criacao);


--
-- Name: IDX_4c4c111efc44499d55fbbabc1c; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_4c4c111efc44499d55fbbabc1c" ON public.atletas_escalados USING btree (posicao);


--
-- Name: IDX_508fa5dcd45311256c19d5aa81; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_508fa5dcd45311256c19d5aa81" ON public.partidas USING btree (data_criacao);


--
-- Name: IDX_55307682a97abeecbe78ef95e2; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_55307682a97abeecbe78ef95e2" ON public.partidas USING btree (id_visitante);


--
-- Name: IDX_5cc47f6d67b56b3f1b6024548d; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_5cc47f6d67b56b3f1b6024548d" ON public.arbitros USING btree (data_criacao);


--
-- Name: IDX_672b2f57320fd03957d23ed7d5; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_672b2f57320fd03957d23ed7d5" ON public.atletas_partida USING btree (id_atleta);


--
-- Name: IDX_726c77443629b22dc96a8ef714; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_726c77443629b22dc96a8ef714" ON public.tecnicos USING btree (id_equipe);


--
-- Name: IDX_756f1be552d523d58d73102dae; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_756f1be552d523d58d73102dae" ON public.arbitros_partida USING btree (id_arbitro);


--
-- Name: IDX_8641a46be0659ebefd28a99895; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_8641a46be0659ebefd28a99895" ON public.delegados USING btree (id_liga);


--
-- Name: IDX_9196779f164c70849d8bcea0d2; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_9196779f164c70849d8bcea0d2" ON public.atletas_partida USING btree (data_criacao);


--
-- Name: IDX_a41964d39d213e87c0f2e40321; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_a41964d39d213e87c0f2e40321" ON public.ginasios USING btree (cidade);


--
-- Name: IDX_aff09371e8b4aedd2d46ef1121; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_aff09371e8b4aedd2d46ef1121" ON public.atletas_escalados USING btree (id_equipe_partida);


--
-- Name: IDX_bd0a9b6e5a48419ff3e660f742; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_bd0a9b6e5a48419ff3e660f742" ON public.ginasios USING btree (data_criacao);


--
-- Name: IDX_c27fddfcd048b78de323b67dba; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_c27fddfcd048b78de323b67dba" ON public.partidas USING btree (tipo_da_rodada);


--
-- Name: IDX_c3d7984e89fc1bc852dfb62484; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_c3d7984e89fc1bc852dfb62484" ON public.votos_da_galera USING btree (telefone, verificado_em);


--
-- Name: IDX_c889de707e36b235a08c65e41c; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_c889de707e36b235a08c65e41c" ON public.equipes USING btree (id_liga);


--
-- Name: IDX_d5b91bb370c911d7060b3b888a; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_d5b91bb370c911d7060b3b888a" ON public.equipes USING btree (data_criacao);


--
-- Name: IDX_dbd8279a19c9d8626420d6a62e; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_dbd8279a19c9d8626420d6a62e" ON public.atletas USING btree (data_criacao);


--
-- Name: IDX_de94a09c62e98501363519b05c; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_de94a09c62e98501363519b05c" ON public.partidas USING btree (id_delegado);


--
-- Name: IDX_df6e397136448e8cd4a3e00b6a; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_df6e397136448e8cd4a3e00b6a" ON public.atletas_partida USING btree (id_partida);


--
-- Name: IDX_e0872826715a9d03d6e1bcdbb1; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_e0872826715a9d03d6e1bcdbb1" ON public.partidas USING btree (id_ginasio);


--
-- Name: IDX_e343fae9dfdbb61550a5b7e26e; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_e343fae9dfdbb61550a5b7e26e" ON public.partidas USING btree (id_mandante);


--
-- Name: IDX_e45b4e2013928b50f0cb7bab0f; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_e45b4e2013928b50f0cb7bab0f" ON public.fundamentos_atletas USING btree (data_criacao);


--
-- Name: IDX_ebef46b3cc90c2843167a4d5f4; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_ebef46b3cc90c2843167a4d5f4" ON public.delegados USING btree (data_criacao);


--
-- Name: IDX_f2e52bb8b002c915b80af6bad6; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_f2e52bb8b002c915b80af6bad6" ON public.arbitros_partida USING btree (id_partida);


--
-- Name: IDX_f53daafa6e9d8554473d5b187a; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_f53daafa6e9d8554473d5b187a" ON public.atletas_escalados USING btree (data_criacao);


--
-- Name: IDX_f72a0deda9a05fa5079ebaf7d3; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_f72a0deda9a05fa5079ebaf7d3" ON public.atletas_escalados USING btree (id_atleta);


--
-- Name: IDX_fd2a1f231e268d846f86915865; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_fd2a1f231e268d846f86915865" ON public.auxiliares USING btree (data_criacao);


--
-- Name: IDX_fe99de4c16afb87c570c956b2b; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IDX_fe99de4c16afb87c570c956b2b" ON public.arbitros USING btree (id_liga);


--
-- Name: IX_craques_da_galera_view_quantidadeVotos; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IX_craques_da_galera_view_quantidadeVotos" ON public.craques_da_galera_view USING btree (quantidade_votos DESC);


--
-- Name: IX_equipes_cidade_estado; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IX_equipes_cidade_estado" ON public.equipes USING btree (cidade, estado);


--
-- Name: IX_ginasios_cidade_estado; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IX_ginasios_cidade_estado" ON public.ginasios USING btree (cidade, estado);


--
-- Name: IX_melhores_centrais_view_media; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IX_melhores_centrais_view_media" ON public.melhores_centrais_view USING btree (quantidade_partidas DESC, bloqueios_por_partida DESC);


--
-- Name: IX_melhores_liberos_view_media; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IX_melhores_liberos_view_media" ON public.melhores_liberos_view USING btree (quantidade_partidas DESC, recepcoes_por_partida DESC);


--
-- Name: IX_melhores_pontas_view_media; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IX_melhores_pontas_view_media" ON public.melhores_pontas_view USING btree (quantidade_partidas DESC, aces_por_partida DESC, saques_efetivos DESC);


--
-- Name: IX_partidas_RemovePartidasSemVencedores; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IX_partidas_RemovePartidasSemVencedores" ON public.partidas USING btree (status) WHERE (id_ganhadora IS NULL);


--
-- Name: IX_partidas_status_tipoDaRodada; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IX_partidas_status_tipoDaRodada" ON public.partidas USING btree (status, tipo_da_rodada);


--
-- Name: IX_pontuacoes_view_pontuacao; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE INDEX "IX_pontuacoes_view_pontuacao" ON public.pontuacoes_view USING btree (pontuacao);


--
-- Name: UQ_craques_da_galera_view_idAtleta; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE UNIQUE INDEX "UQ_craques_da_galera_view_idAtleta" ON public.craques_da_galera_view USING btree (id_atleta);


--
-- Name: UQ_melhores_centrais_view_idAtleta; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE UNIQUE INDEX "UQ_melhores_centrais_view_idAtleta" ON public.melhores_centrais_view USING btree (id_atleta);


--
-- Name: UQ_melhores_liberos_view_idAtleta; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE UNIQUE INDEX "UQ_melhores_liberos_view_idAtleta" ON public.melhores_liberos_view USING btree (id_atleta);


--
-- Name: UQ_melhores_pontas_view_idAtleta; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE UNIQUE INDEX "UQ_melhores_pontas_view_idAtleta" ON public.melhores_pontas_view USING btree (id_atleta);


--
-- Name: UQ_pontuacoes_view_id_equipe; Type: INDEX; Schema: public; Owner: voleibol
--

CREATE UNIQUE INDEX "UQ_pontuacoes_view_id_equipe" ON public.pontuacoes_view USING btree (id_equipe);


--
-- Name: auxiliares FK_185c120f3624970475d8f1df84b; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.auxiliares
    ADD CONSTRAINT "FK_185c120f3624970475d8f1df84b" FOREIGN KEY (id_equipe) REFERENCES public.equipes(id) ON DELETE CASCADE;


--
-- Name: partidas FK_2dcc30b378f8e69aedb263a0465; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.partidas
    ADD CONSTRAINT "FK_2dcc30b378f8e69aedb263a0465" FOREIGN KEY (id_ganhadora) REFERENCES public.equipes_partidas(id) ON DELETE SET NULL;


--
-- Name: votos_da_galera FK_43c84e78723e7f2a80af90cd9fb; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.votos_da_galera
    ADD CONSTRAINT "FK_43c84e78723e7f2a80af90cd9fb" FOREIGN KEY (id_atleta) REFERENCES public.atletas(id) ON DELETE CASCADE;


--
-- Name: atletas FK_442b67bb04c95a2e04ebbbd83be; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas
    ADD CONSTRAINT "FK_442b67bb04c95a2e04ebbbd83be" FOREIGN KEY (id_equipe) REFERENCES public.equipes(id) ON DELETE CASCADE;


--
-- Name: fundamentos_atletas FK_449fe4c78fb88327cd9e94c544e; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.fundamentos_atletas
    ADD CONSTRAINT "FK_449fe4c78fb88327cd9e94c544e" FOREIGN KEY (id_atleta_escalado) REFERENCES public.atletas_escalados(id) ON DELETE CASCADE;


--
-- Name: partidas FK_55307682a97abeecbe78ef95e2b; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.partidas
    ADD CONSTRAINT "FK_55307682a97abeecbe78ef95e2b" FOREIGN KEY (id_visitante) REFERENCES public.equipes_partidas(id) ON DELETE CASCADE;


--
-- Name: tecnicos FK_606c789ebbaf0670a39edf937c3; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.tecnicos
    ADD CONSTRAINT "FK_606c789ebbaf0670a39edf937c3" FOREIGN KEY (id_pessoa) REFERENCES public.pessoas(id) ON DELETE CASCADE;


--
-- Name: auxiliares FK_63186f3f51e662a98fb04c176b7; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.auxiliares
    ADD CONSTRAINT "FK_63186f3f51e662a98fb04c176b7" FOREIGN KEY (id_pessoa) REFERENCES public.pessoas(id) ON DELETE CASCADE;


--
-- Name: atletas_partida FK_672b2f57320fd03957d23ed7d5e; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas_partida
    ADD CONSTRAINT "FK_672b2f57320fd03957d23ed7d5e" FOREIGN KEY (id_atleta) REFERENCES public.atletas(id);


--
-- Name: arbitros FK_7175f8ecb699effccd191c530d3; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.arbitros
    ADD CONSTRAINT "FK_7175f8ecb699effccd191c530d3" FOREIGN KEY (id_pessoa) REFERENCES public.pessoas(id) ON DELETE CASCADE;


--
-- Name: tecnicos FK_726c77443629b22dc96a8ef714d; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.tecnicos
    ADD CONSTRAINT "FK_726c77443629b22dc96a8ef714d" FOREIGN KEY (id_equipe) REFERENCES public.equipes(id) ON DELETE CASCADE;


--
-- Name: arbitros_partida FK_756f1be552d523d58d73102dae1; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.arbitros_partida
    ADD CONSTRAINT "FK_756f1be552d523d58d73102dae1" FOREIGN KEY (id_arbitro) REFERENCES public.arbitros(id) ON DELETE CASCADE;


--
-- Name: delegados FK_8641a46be0659ebefd28a998956; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.delegados
    ADD CONSTRAINT "FK_8641a46be0659ebefd28a998956" FOREIGN KEY (id_liga) REFERENCES public.ligas(id) ON DELETE CASCADE;


--
-- Name: atletas FK_8673430de4ae5ab7edf8dba98c1; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas
    ADD CONSTRAINT "FK_8673430de4ae5ab7edf8dba98c1" FOREIGN KEY (id_pessoa) REFERENCES public.pessoas(id) ON DELETE CASCADE;


--
-- Name: delegados FK_a2b5b0b570956c36475eeb066c3; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.delegados
    ADD CONSTRAINT "FK_a2b5b0b570956c36475eeb066c3" FOREIGN KEY (id_pessoa) REFERENCES public.pessoas(id) ON DELETE CASCADE;


--
-- Name: atletas_escalados FK_aff09371e8b4aedd2d46ef1121e; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas_escalados
    ADD CONSTRAINT "FK_aff09371e8b4aedd2d46ef1121e" FOREIGN KEY (id_equipe_partida) REFERENCES public.equipes_partidas(id) ON DELETE CASCADE;


--
-- Name: equipes_partidas FK_b38dc0d6c02b7dc8d01243694fe; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.equipes_partidas
    ADD CONSTRAINT "FK_b38dc0d6c02b7dc8d01243694fe" FOREIGN KEY (id_partida) REFERENCES public.partidas(id) ON DELETE CASCADE;


--
-- Name: equipes FK_b5b45eae06b288f11e5b3fcc38e; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.equipes
    ADD CONSTRAINT "FK_b5b45eae06b288f11e5b3fcc38e" FOREIGN KEY (id_ginasio) REFERENCES public.ginasios(id);


--
-- Name: equipes_partidas FK_b619e7a5725eaaf9ec76efbc0ff; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.equipes_partidas
    ADD CONSTRAINT "FK_b619e7a5725eaaf9ec76efbc0ff" FOREIGN KEY (id_equipe) REFERENCES public.equipes(id) ON DELETE CASCADE;


--
-- Name: equipes FK_c889de707e36b235a08c65e41ca; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.equipes
    ADD CONSTRAINT "FK_c889de707e36b235a08c65e41ca" FOREIGN KEY (id_liga) REFERENCES public.ligas(id) ON DELETE CASCADE;


--
-- Name: partidas FK_de94a09c62e98501363519b05cf; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.partidas
    ADD CONSTRAINT "FK_de94a09c62e98501363519b05cf" FOREIGN KEY (id_delegado) REFERENCES public.delegados(id) ON DELETE SET NULL;


--
-- Name: atletas_partida FK_df6e397136448e8cd4a3e00b6a3; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas_partida
    ADD CONSTRAINT "FK_df6e397136448e8cd4a3e00b6a3" FOREIGN KEY (id_partida) REFERENCES public.partidas(id);


--
-- Name: partidas FK_e0872826715a9d03d6e1bcdbb14; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.partidas
    ADD CONSTRAINT "FK_e0872826715a9d03d6e1bcdbb14" FOREIGN KEY (id_ginasio) REFERENCES public.ginasios(id);


--
-- Name: partidas FK_e343fae9dfdbb61550a5b7e26e7; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.partidas
    ADD CONSTRAINT "FK_e343fae9dfdbb61550a5b7e26e7" FOREIGN KEY (id_mandante) REFERENCES public.equipes_partidas(id) ON DELETE CASCADE;


--
-- Name: arbitros_partida FK_f2e52bb8b002c915b80af6bad60; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.arbitros_partida
    ADD CONSTRAINT "FK_f2e52bb8b002c915b80af6bad60" FOREIGN KEY (id_partida) REFERENCES public.partidas(id) ON DELETE CASCADE;


--
-- Name: atletas_escalados FK_f72a0deda9a05fa5079ebaf7d3e; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.atletas_escalados
    ADD CONSTRAINT "FK_f72a0deda9a05fa5079ebaf7d3e" FOREIGN KEY (id_atleta) REFERENCES public.atletas(id) ON DELETE CASCADE;


--
-- Name: arbitros FK_fe99de4c16afb87c570c956b2bf; Type: FK CONSTRAINT; Schema: public; Owner: voleibol
--

ALTER TABLE ONLY public.arbitros
    ADD CONSTRAINT "FK_fe99de4c16afb87c570c956b2bf" FOREIGN KEY (id_liga) REFERENCES public.ligas(id) ON DELETE CASCADE;


--
-- Name: craques_da_galera_view; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: voleibol
--

REFRESH MATERIALIZED VIEW public.craques_da_galera_view;


--
-- Name: melhores_centrais_view; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: voleibol
--

REFRESH MATERIALIZED VIEW public.melhores_centrais_view;


--
-- Name: melhores_liberos_view; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: voleibol
--

REFRESH MATERIALIZED VIEW public.melhores_liberos_view;


--
-- Name: melhores_pontas_view; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: voleibol
--

REFRESH MATERIALIZED VIEW public.melhores_pontas_view;


--
-- Name: pontuacoes_view; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: voleibol
--

REFRESH MATERIALIZED VIEW public.pontuacoes_view;


--
-- PostgreSQL database dump complete
--

